from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Direction, Button
from pybricks.hubs import PrimeHub
from pybricks.tools import wait, StopWatch
from Tools import PIDController, LinearDecelerationRamp
from umath import pi, cos
from Tools import mostrarBateria



class Chassi:
    
    def __init__(self, portaEsquerda, portaDireita, d = 5.6, trackwidth = 13.14):
        self.motorEsquerdo = Motor(portaEsquerda)
        self.motorDireito = Motor(portaDireita, Direction.COUNTERCLOCKWISE)
        self.hub = PrimeHub()
        
        

        #PARAMS
        self.velocidadeMinima = 50
        self.velocidadeMinimaCurva = 10
        self.distanciaNecessariaParaFrear = 12
        self.distanciaNecessariaParaFrearCurvas = 60

        # parametros para contas cinemáticas
        self.d = d
        self.trackwidth = trackwidth
        self.circunferenciaDaRoda = self.d * pi

        # pid
        self.kp = 30
        self.ki = 0.0001
        self.kd = 17

    #Funções para alterar os valores das constantes PID
    #Proporcional (KP):
    def alterarProporcional(self, kp = 30):
        self.kp = kp

    #Integral (KI):
    def alterarIntegral(self, ki = 0.0001):
        self.ki = ki

    #Derivada (KD):
    def alterarDerivada(self, kd = 17):
        self.kd = kd

    #Função para conferir se a programação deve parar(botão pressionado)
    def checkStop(self):
        pressed = self.hub.buttons.pressed()
        if(Button.CENTER in pressed):
            return True
        return False

    #Autopilotagem: Movimentação do robô com correção do ângulo do robô com valores PID
    def autopilotagem(self, setPoint, distanciaAlvoEmCm, velocidadeInicial, modoTeste = False, desacelerar=True):
     if self.hub.imu.ready() == True:

        self.motorDireito.reset_angle(0)
        self.motorEsquerdo.reset_angle(0)

        kp= self.kp
        ki= self.ki
        kd= self.kd

        controlePid  = PIDController(kp, ki, kd)
        controlePid.set_setpoint(setPoint)   
        if desacelerar:
            rampa = LinearDecelerationRamp(velocidadeInicial, self.velocidadeMinima, abs(distanciaAlvoEmCm), self.distanciaNecessariaParaFrear)   
        
        stopped = False
        
        verificacao = -1 if distanciaAlvoEmCm < 0 else 1
        cronometro = StopWatch()
        cronometro.reset()
        
        #Movimentação do Robô:
        distanciaEmCmMotorEsquerdo = (self.motorEsquerdo.angle() / 360) * self.circunferenciaDaRoda
        distanciaEmCmMotorDireito = (self.motorDireito.angle() / 360) * self.circunferenciaDaRoda
        distanciaPercorridaEmCm = (distanciaEmCmMotorDireito + distanciaEmCmMotorEsquerdo / 2)

        while abs(distanciaAlvoEmCm) > abs(distanciaPercorridaEmCm) and not stopped:
            if self.checkStop() and cronometro.time() > 200:
                stopped = True
                break

            correcao = controlePid.update(self.hub.imu.heading())
            if desacelerar:
                velocidade = rampa.calculate_speed(abs(distanciaPercorridaEmCm))
            else: 
                velocidade = velocidadeInicial

            distanciaEmCmMotorEsquerdo = (self.motorEsquerdo.angle() / 360) * self.circunferenciaDaRoda
            #print(f"LM CM: {distanciaEmCmMotorEsquerdo} LM deg: {self.motorEsquerdo.angle()}")
            distanciaEmCmMotorDireito = (self.motorDireito.angle() / 360) * self.circunferenciaDaRoda
            #print(f"RM CM: {distanciaEmCmMotorDireito} LM deg : {self.motorDireito.angle()}")
            distanciaPercorridaEmCm = (distanciaEmCmMotorDireito + distanciaEmCmMotorEsquerdo) / 2
            #print(f"Distancia Total: {distanciaPercorridaEmCm}")

            self.motorDireito.run(verificacao * (velocidade + (correcao * verificacao)))
            self.motorEsquerdo.run(verificacao * (velocidade - (correcao * verificacao)))

        self.motorDireito.brake()
        self.motorEsquerdo.brake()

        adicional = 0
        if modoTeste and not stopped :
            adicional = 1000
            wait(1000)
        
        print("==============================")
        print("=====DISTANCIA AO FINAL=====")
        print("===============================")
        distanciaEmCmMotorEsquerdo = (self.motorEsquerdo.angle() / 360) * self.circunferenciaDaRoda
        #print(f"LM CM: {distanciaEmCmMotorEsquerdo} LM deg: {self.motorEsquerdo.angle()}")
        distanciaEmCmMotorDireito = (self .motorDireito.angle() / 360) * self.circunferenciaDaRoda
        #print(f"RM CM: {distanciaEmCmMotorDireito} LM deg : {self.motorDireito.angle()}")
        distanciaPercorridaEmCm = (distanciaEmCmMotorDireito + distanciaEmCmMotorEsquerdo) / 2
        print(f"Distancia Total: {distanciaPercorridaEmCm}")
        print(f"Tempo: {(cronometro.time() - adicional) / 1000}s \n Velocidade média: {distanciaPercorridaEmCm / (cronometro.time() / 1000)}cm/s")
        #mostrarBateria()
        print("========================")
        if modoTeste and not stopped:
            wait(10000)
        return(stopped)
         
    
    
    
    
    #Curva
    def curva(self, anguloAlvo, velocidadeInicial = 500, teste = False, desacelerar=True):
     if self.hub.imu.ready() == True:
        velocidade = velocidadeInicial
        #resetar os angulos
        self.motorDireito.reset_angle()
        self.motorEsquerdo.reset_angle()
        
        anguloInicial = self.hub.imu.heading()
        percursoTotal = anguloAlvo - anguloInicial

        stopped = False
        #buildando rampa

        rampa = LinearDecelerationRamp(velocidadeInicial, self.velocidadeMinimaCurva, percursoTotal, self.distanciaNecessariaParaFrearCurvas)
        
        cronometro = StopWatch()
        cronometro.reset()
        #decidindo qual tipo de curva
        if anguloAlvo > anguloInicial:
              rampa = LinearDecelerationRamp(velocidadeInicial, self.velocidadeMinima, percursoTotal, self.distanciaNecessariaParaFrearCurvas)
              while anguloAlvo > self.hub.imu.heading() and not stopped:
                if self.checkStop() and cronometro.time() > 200:
                    stopped = True
                    break
                velocidade = rampa.calculate_speed(self.hub.imu.heading() - anguloInicial)

                
                self.motorDireito.run(velocidade)
                self.motorEsquerdo.run(-velocidade)

        if anguloAlvo < anguloInicial:

              rampa = LinearDecelerationRamp(velocidadeInicial, self.velocidadeMinima, -percursoTotal, self.distanciaNecessariaParaFrearCurvas) 
              while anguloAlvo < self.hub.imu.heading() and not stopped:
                if self.checkStop() and cronometro.time() > 200:
                    stopped = True
                    break
                velocidade = rampa.calculate_speed(abs(self.hub.imu.heading() - anguloInicial))

                print(velocidade)
                self.motorDireito.run(-velocidade)
                self.motorEsquerdo.run(velocidade)

        
        
        self.motorDireito.brake()
        self.motorEsquerdo.brake()
        aguardo = 0
        if teste and not stopped:
            aguardo = 1000
            wait(1000)

        print("==============================")
        print("======DISTANCIA AO FINAL=======")
        print("===============================")

        print(f"Posição Angular Final: {self.hub.imu.heading()}")
        print(f"Tempo: {(cronometro.time() - aguardo) / 1000}s Velocidade média: {percursoTotal / ((cronometro.time() - aguardo) / 1000)}º/s")

        print("========================")

        if teste  and not stopped:
            wait(5000)
            
    
        return(stopped)

    def startPID(self):
        self.alterarProporcional()
        self.alterarIntegral()
        self.alterarDerivada()