from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
from pybricks.tools import hub_menu
hub = PrimeHub()

motorDireita = Motor(Port.A)
motorEsquerda = Motor(Port.E, Direction.COUNTERCLOCKWISE)
motoranexoEsq = Motor(Port.F)


def autopilotagem(setpoint, distanciaEmCm, velocidadeInicial):
    if hub.imu.ready() == True:
        # Resetando valores
        hub.imu.reset_heading(0)
        motorDireita.reset_angle(0)
        motorEsquerda.reset_angle(0)

        # Cálculo do ângulo percorrido pelos motores
        motorDireitaAngulo = ((motorDireita.angle() / 360) * 17.58)
        motorEsquerdaAngulo = ((motorEsquerda.angle() / 360) * 17.58)
        movimentacaoDoRobo = (motorDireitaAngulo + motorEsquerdaAngulo) / 2

        # Definindo os ganhos PID
        kp = 31
        kd = 20.052884615384615

        # Verificação de direção (se a distância é negativa ou não)
        verificacao = 1 
        if distanciaEmCm < 0:
            verificacao = -1

        # Inicializando o erro
        ultimoerro = 0
        percursoTotalDcc = 10  # Percurso total de correção, ajuste conforme necessário
        percursoTotal = abs(distanciaEmCm)
        
        # Loop principal de movimentação
        while movimentacaoDoRobo < abs(distanciaEmCm):
            # Atualizando os ângulos dos motores
            motorDireitaAngulo = ((abs(motorDireita.angle()) / 360) * 17.58)
            motorEsquerdaAngulo = ((abs(motorEsquerda.angle()) / 360) * 17.58)
            movimentacaoDoRobo = (motorDireitaAngulo + motorEsquerdaAngulo) / 2
            percursoFeito = movimentacaoDoRobo

            # Cálculo do erro de percurso
            percursoFeitoDcc = percursoFeito - (percursoTotal - percursoTotalDcc)

            # Cálculo do erro de direção (PID)
            erro = setpoint - hub.imu.heading()
            proporcional = erro * kp
            deltaE = erro - ultimoerro
            derivada = deltaE * kd
            correcao = proporcional + derivada

            # Cálculo da velocidade ajustada
            velocidade = abs(velocidadeInicial) - ((percursoFeitoDcc / percursoTotalDcc) * abs(velocidadeInicial))
            
            # Garantindo que a velocidade não caia abaixo de um valor mínimo
            velocidadeMinima = 46
            if abs(velocidade) < velocidadeMinima:
                velocidade = velocidadeMinima

            # Aplicando a correção nos motores
            motorDireita.run((velocidade * verificacao) - correcao)
            motorEsquerda.run((velocidade * verificacao) + correcao)

            # Exibindo o progresso
            print(f"Percurso Feito: {percursoFeito} cm")

            # Atualizando o último erro
            ultimoerro = erro

        # Parando os motores quando o percurso for concluído
        motorDireita.brake()
        motorEsquerda.brake()


def curva(angulo):  
 if hub.imu.ready() == True:
    hub.imu.reset_heading(0)
    #print("COMEÇA AGORA")
    valorInicial = abs(hub.imu.heading())
    valorAlvo = valorInicial + (angulo)
    
    if angulo > 0:
        #iniciar movimentos direita
        motorEsquerda.run(250)
        motorDireita.run(-250)
        
        while abs(hub.imu.heading()) < valorAlvo or abs(hub.imu.heading()) == valorAlvo:

                if abs(hub.imu.heading()) > abs(valorAlvo - 30):
                        wait(10)
                        motorEsquerda.run(100)
                        motorDireita.run(-100)
    if angulo < 0:
        #iniciar movimentos esquerda

        motorDireita.reset_angle(0)
        motorEsquerda.reset_angle(0)
    
    
        motorDireitaAngulo =  ((motorDireita.angle() / 360) * 17.58)
        motorEsquerdaAngulo = ((motorEsquerda.angle() / 360) * 17.58)
        movimentacaoDoRobo =  (motorDireitaAngulo + motorEsquerdaAngulo) / 2
        percursoTotalDcc = 1
        velocidadeInicial = 500

        while (abs(hub.imu.heading()) * -1 ) > (valorAlvo) or (abs(hub.imu.heading()) * -1) == (valorAlvo):
                
            percursoTotal = valorAlvo
            percursoFeito = movimentacaoDoRobo

            velocidadeMinima = 200
            #Movimentação do robo
            motorDireitaAngulo =  ((motorDireita.angle() / 360) * 17.58)
            motorEsquerdaAngulo = ((motorEsquerda.angle() / 360) * 17.58)
            movimentacaoDoRobo =  (motorDireitaAngulo + motorEsquerdaAngulo) / 2
            
            percursoFeitoDcc = percursoFeito - (percursoTotal - percursoTotalDcc)


            velocidade = (velocidadeInicial - ((percursoFeitoDcc / percursoTotalDcc) * velocidadeInicial))

            if movimentacaoDoRobo < valorAlvo - percursoTotalDcc:
                velocidade = velocidadeInicial

            if velocidade < velocidadeMinima:
                velocidade = velocidadeMinima

            motorEsquerda.run(velocidade * -1)
            motorDireita.run(velocidade)

'''
selecionado = hub_menu("1", "2", "3", "4", "5", "6")
if selecionado == "1":
    motoranexoEsq.run_angle(400, 10)
elif selecionado == "2":
    #ele vai pro polvo
    motorAnexoEsq.run_target(500, -180)
    wait(500)
    motorAnexoEsq.reset_angle(0)
    autopilotagem(0, 24, 700)
    wait(500)

    motorDireita.brake()
    motorEsquerda.brake()  
    wait(500)
'''
selecionado = hub_menu("1", "2", "3", "4", "5", "6")
if selecionado == "1":
    motoranexoEsq.run_angle(400, 10)
else selecionado == 2
#ele vai pro polvo
    motorAnexoEsq.run_target(500, -180)
    wait(500)
    motorAnexoEsq.reset_angle(0)
    #dsdsa
    autopilotagem(0, 24, 700)
    wait(500)
    curva(45)
    wait(500)
    autopilotagem(0, 31, 500)
    wait(500)
    #vira pro polvo
    curva(42)
    #faz o polvo
    autopilotagem(0, 15, 350)
    wait(500)
    autopilotagem(0, -15, 500)
    #coral
    curva(90)
    wait(500)
    autopilotagem(0, -25, 500)
    wait(500)
    #ta fazendo o coral
    curva(-88)
    wait(500)
    motorAnexoEsq.run_angle(500, 48)
    #sadsasas
    #motoranexoEsq.run_angle(400, 10) #garra abaixa
    motorDireita.run(-400)
    motorEsquerda.run(-400)
    wait(1500)
    #autopilotagem(0, 1, 400)
    #pega o mergulhador
    motoranexoEsq.run_time(-900, 3000)
elif selecionado == "6":
    #wiueop
    autopilotagem(0, 27, 800)
    wait(500)
    motorAnexoDir.run_time(-100, 1000)
    autopilotagem(0, 70, 500)
    motorAnexoEsq.run_time(900, 700)
    motorAnexoDir.run_angle(900, 90)
    autopilotagem(0, -21, 400)
    wait(1000)
    motorAnexoEsq.run_target(-900, -200)
    motorAnexoDir.run_time(-200, 1000)
    autopilotagem(0, 20, 600)
    autopilotagem(0, -25, 600)
    curva(-40)
    #CARANGUEJO

print(selecionado)