
from LegoRunner import *

# Rota 1
movimentosRota1 = [

 prepare(chassiDoRobo.autopilotagem, 0, 20, 500),
 prepare(wait, 1000)
]

rota1 = Rota('a', movimentosRota1, "rota um")

#adiciona as rotas
adicionarRota(rota1)

menu.mostrar()