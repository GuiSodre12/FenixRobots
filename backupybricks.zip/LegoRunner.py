from pybricks.parameters import Port
from pybricks.tools import Matrix
from pybricks.tools import wait, StopWatch

# arquivos necessários
from Chassi import Chassi
from Rota import Rota
from Tools import prepare, Menu, mostrarBateria
from pybricks.pupdevices import Motor

# criar o chassi
chassiDoRobo = Chassi(Port.A, Port.E)


#criar o menu
menu = Menu([], chassiDoRobo.hub, chassiDoRobo)

# adiciona rota
def adicionarRota(rota):
    menu.adicionarRota(rota)