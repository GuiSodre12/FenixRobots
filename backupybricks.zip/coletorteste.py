from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

motorDireita = Motor(Port.A)  # Motor da roda direita
motorEsquerda = Motor(Port.E, Direction.COUNTERCLOCKWISE)  # Motor da roda esquerda
motorAnexoEsq = Motor(Port.F)  # Motor do anexo esquerdo
motorAnexoDir = Motor(Port.D)  # Motor do anexo direito
time = StopWatch()

#motorAnexoEsq.run_time(-3000, 1000)
#motorDireita.run(3000)
#MotorDireita.run(-2000)
#motorEsquerda.run(2000)
#wait(900)
#motorAnexoDir.run(-3000)
motorAnexoEsq.run(3000)
wait(2000)