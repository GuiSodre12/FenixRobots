from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()
motorDireita = Motor(Port.A)  # Motor da roda direita
motorEsquerda = Motor(Port.E, Direction.COUNTERCLOCKWISE)  # Motor da roda esquerda
motorAnexoEsq = Motor(Port.F)  # Motor do anexo esquerdo
motorAnexoDir = Motor(Port.D)  # Motor do anexo direito
time = StopWatch()
kp = 30
velocidadeMinima = 46
def mostrarAngulo():
    if(time.time() % 100 < 2):
            print(f"Angulo: {hub.imu.heading()}")

def autopilotagem(setpoint, distanciaEmCm, velocidadeInicial, modoTeste = False):
    if hub.imu.ready() == True:
        # Resetando valores
        # hub.imu.reset_heading(0)
        motorDireita.reset_angle(0)
        motorEsquerda.reset_angle(0)

        # Cálculo do ângulo percorrido pelos motores
        motorDireitaAngulo = ((motorDireita.angle() / 360) * 17.58)
        motorEsquerdaAngulo = ((motorEsquerda.angle() / 360) * 17.58)
        movimentacaoDoRobo = (motorDireitaAngulo + motorEsquerdaAngulo) / 2

        # Definindo os ganhos PID

        kd = 20.052884615384615

        # Verificação de direção (se a distância é negativa ou não)
        verificacao = 1 
        if distanciaEmCm < 0:
            verificacao = -1

        # Inicializando o erro
        ultimoerro = 0
        percursoTotalDcc = 10  # Percurso total de correção, ajuste conforme necessário
        percursoTotal = abs(distanciaEmCm)
        pontoDcc = (percursoTotal - percursoTotalDcc)

        # Loop principal de movimentação
        while movimentacaoDoRobo < abs(distanciaEmCm):
            # Atualizando os ângulos dos motores
            motorDireitaAngulo = ((abs(motorDireita.angle()) / 360) * 17.58)
            motorEsquerdaAngulo = ((abs(motorEsquerda.angle()) / 360) * 17.58)
            movimentacaoDoRobo = (motorDireitaAngulo + motorEsquerdaAngulo) / 2
            percursoFeito = movimentacaoDoRobo

            # Cálculo do erro de percurso
            percursoFeitoDcc = percursoFeito - (percursoTotal - percursoTotalDcc)
            
            # Cálculo do erro de direção (PID)
            erro = setpoint - hub.imu.heading()
            proporcional = erro * kp
            deltaE = erro - ultimoerro
            derivada = deltaE * kd
            correcao = proporcional + derivada

            # Cálculo da velocidade ajustada]
            velocidade = velocidadeInicial
            if(movimentacaoDoRobo > pontoDcc):
                velocidade = abs(velocidadeInicial) - ((percursoFeitoDcc / percursoTotalDcc) * abs(velocidadeInicial))
            
            # Garantindo que a velocidade não caia abaixo de um valor mínimo
            
            if abs(velocidade) < velocidadeMinima:
                velocidade = velocidadeMinima

            # Aplicando a correção nos motores
            motorDireita.run((velocidade * verificacao) - correcao)
            motorEsquerda.run((velocidade * verificacao) + correcao)

            # Exibindo o progresso
            if  time.time() % 200 < 2:
                print(f"vd: {(velocidade * verificacao) - correcao} || ve: {(velocidade * verificacao) + correcao} || Ângulo atual: {hub.imu.heading()} || erro: {erro} || correção: {correcao}")
               
            # Atualizando o último erro
            ultimoerro = erro

        # Parando os motores quando o percurso for concluído
        mostrarAngulo()
        motorDireita.brake()
        motorEsquerda.brake()


        if modoTeste :
            wait(1000)
            print('=================================')
            print(f'ÂNGULO FINAL : {hub.imu.heading()}º')
            print(f'POSIÇÃO FINAL: {movimentacaoDoRobo}cm')
            print('=================================')

def curva(anguloAlvo, velocidadeInicial):
    if hub.imu.ready() == True:
        #velocidadeInicial = 300
        velocidadeMinima = 60

        posicaoInicial = hub.imu.heading()
        posicaoFinal  = anguloAlvo

        #PERCURSOS
        percursoTotal = posicaoFinal - posicaoInicial
        percursoFeito = hub.imu.heading() - posicaoInicial
        motorDireitaAngulo = ((motorDireita.angle() / 360) * 17.58)
        motorEsquerdaAngulo = ((motorEsquerda.angle() / 360) * 17.58)
        movimentacaoDoRobo = (motorDireitaAngulo + motorEsquerdaAngulo) / 2


        if percursoTotal > 0:
            verificacao = 1
        else:
            verificacao = -1

        #PERCURSOS
        percursoTotalDcc = 60 * verificacao
        pontoDcc = posicaoFinal - percursoTotalDcc
        percursoFeitoDcc = percursoFeito - pontoDcc

        if posicaoInicial < posicaoFinal:
            while hub.imu.heading() < posicaoFinal:
                posicaoAtual = hub.imu.heading()

                percursoFeito = hub.imu.heading() - posicaoInicial
                pontoDcc = posicaoFinal - percursoTotalDcc
                percursoFeitoDcc = percursoFeito - pontoDcc

                
                
                if posicaoAtual < pontoDcc:
                    velocidade = velocidadeInicial
                else:
                    velocidade = abs(velocidadeInicial) -  ((percursoFeitoDcc / percursoTotalDcc) * abs(velocidadeInicial))

            
                if velocidade < velocidadeMinima:
                    velocidade = velocidadeMinima

                mostrarAngulo()
                motorDireita.run(-velocidade)
                motorEsquerda.run(velocidade)
                print(hub.imu.heading())
                print(f'velocidade:{velocidade}, percursoFeito:{(percursoFeito)}, percursoTotal:{(percursoTotal)}, percursoFeitoDcc:{abs(percursoFeitoDcc)}, percursoTotalDcc:{percursoTotalDcc}')
        else:
            while hub.imu.heading() > posicaoFinal:
                posicaoAtual = hub.imu.heading()

                percursoFeito = hub.imu.heading() - posicaoInicial
                pontoDcc = posicaoFinal - percursoTotalDcc
                percursoFeitoDcc = percursoFeito - pontoDcc

                
                
                if posicaoAtual < pontoDcc:
                    velocidade = velocidadeInicial
                else:
                    velocidade = abs(velocidadeInicial) -  ((percursoFeitoDcc / percursoTotalDcc) * abs(velocidadeInicial))

            
                if velocidade < velocidadeMinima:
                    velocidade = velocidadeMinima

                #mostrarAngulo()
                motorDireita.run(velocidade)
                motorEsquerda.run(-velocidade)

        mostrarAngulo()
        motorDireita.brake() 
        motorEsquerda.brake()
        wait(500)
        print('=================================')
        print(f'ANGULO FINAL : {hub.imu.heading()}º')
        print(f'POSIÇÃO FINAL: {movimentacaoDoRobo}cm')
        print('=================================')



#abaixa o anexo
motorAnexoDir.run(-1000)
motorAnexoEsq.run(1000)
wait(500)
motorAnexoDir.stop()
motorAnexoEsq.stop()

wait(1000)
# levanta o anexo
autopilotagem(0, 10, 500)
motorAnexoDir.run(1000)
motorAnexoEsq.run(-1000)
wait(250)
autopilotagem(0, 10, 500)
wait(1000)
motorAnexoDir.stop()
motorAnexoEsq.stop()
