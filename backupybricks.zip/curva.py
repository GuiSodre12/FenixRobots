from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
time = StopWatch()

hub = PrimeHub()
motorDireita = Motor(Port.E)
motorEsquerda = Motor(Port.A, Direction.COUNTERCLOCKWISE)

def mostrarAngulo():
    if(time.time() % 100 < 2):
        print(f"Angulo: {hub.imu.heading()}")



def curva(anguloAlvo):
    velocidadeInicial = 700
    velocidadeMinima = 30

    posicaoInicial = hub.imu.heading()
    posicaoFinal  = anguloAlvo

    #PERCURSOS
    percursoTotal = posicaoFinal - posicaoInicial
    percursoFeito = hub.imu.heading() - posicaoInicial

    if percursoTotal > 0:
        verificacao = 1
    else:
        verificacao = -1

    #PERCURSOS
    percursoTotalDcc = 60 * verificacao
    pontoDcc = posicaoFinal - percursoTotalDcc
    percursoFeitoDcc = percursoFeito - pontoDcc

    if posicaoInicial < posicaoFinal:
        while hub.imu.heading() < posicaoFinal:
            posicaoAtual = hub.imu.heading()

            percursoFeito = hub.imu.heading() - posicaoInicial
            pontoDcc = posicaoFinal - percursoTotalDcc
            percursoFeitoDcc = percursoFeito - pontoDcc

            
            
            if posicaoAtual < pontoDcc:
                velocidade = velocidadeInicial
            else:
                velocidade = abs(velocidadeInicial) -  ( (percursoFeitoDcc / percursoTotalDcc) * abs(velocidadeInicial))

           
            if velocidade < velocidadeMinima:
                velocidade = velocidadeMinima

            mostrarAngulo()
            motorDireita.run(-velocidade)
            motorEsquerda.run(velocidade)
            print(hub.imu.heading())
            print(f'velocidade:{velocidade}, percursoFeito:{(percursoFeito)}, percursoTotal:{(percursoTotal)}, percursoFeitoDcc:{abs(percursoFeitoDcc)}, percursoTotalDcc:{percursoTotalDcc}')
    else:
        while hub.imu.heading() > posicaoFinal:
            #mostrarAngulo()
            motorDireita.run(-velocidade)
            motorEsquerda.run(velocidade)

    mostrarAngulo()    
    motorDireita.brake() 
    motorEsquerda.brake()

curva(90)

wait(1000)
print('=================================')
print(f'POSICAO FINAL: {hub.imu.heading()}')
print('=================================')


#percursoFeito = heading() - Posição Inicial #no while
#percursoTotal = anguloAlvo - Posição Inicial

#percursoFeitoDcc = PercursoFeito - (PercursoTotal - PercursoTotalDcc)
#percursoTotalDcc =  Distancia Necessaria Para Desacelerar

