from pybricks.parameters import Icon
from pybricks.tools import Matrix

SQUARE = Matrix(
    [
        [100, 100, 100, 100, 100],
        [100, 50, 50, 50, 100],
    ]
)

class Rota:

    def __init__(self, imagem, rota, nome):

        self.rota = rota
        self.imagem = imagem
        self.nome = nome 

        if isinstance(self.imagem, str):
            self.tipo = "char"
        elif isinstance(self.imagem, int):
            self.tipo = "int"
        elif (type(self.imagem) == type(Icon.ARROW_DOWN)):  # Supondo que Icon.UP seja um objeto ou uma constante
            self.tipo = "icon/imagem"
        else:
            raise ValueError("Tipo de imagem não reconhecido.")


    def run(self):
        for action in self.rota:
            stopIsRequested = action()
            if(stopIsRequested):
                print('interrompendo a rota no meio')
                return True
                break
