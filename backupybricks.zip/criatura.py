from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()
'''
motorDireita = Motor(Port.A)  # Motor da roda direita
motorEsquerda = Motor(Port.E, Direction.COUNTERCLOCKWISE)  # Motor da roda esquerda
motorAnexoEsq = Motor(Port.F)  # Motor do anexo esquerdo
motorAnexoDir = Motor(Port.D)  # Motor do anexo direito
time = StopWatch()
curvas = 0
autops = 0
velocidadeMinima = 50
def mostrarAngulo():
    if(time.time() % 100 < 2):
            print(f"Angulo: {hub.imu.heading()}")


def autopilotagem(setpoint, distanciaEmCm, velocidadeInicial):
    global autops
    autops = autops + 1
    if hub.imu.ready() == True:
        # Resetando valores
        # hub.imu.reset_heading(0)
        motorDireita.reset_angle(0)
        motorEsquerda.reset_angle(0)

        # Cálculo do ângulo percorrido pelos motores
        motorDireitaAngulo = ((motorDireita.angle() / 360) * 17.58)
        motorEsquerdaAngulo = ((motorEsquerda.angle() / 360) * 17.58)
        movimentacaoDoRobo = (motorDireitaAngulo + motorEsquerdaAngulo) / 2

        # Definindo os ganhos PID
        kp = 20
        kd = 20.052884615384615

        # Verificação de direção (se a distância é negativa ou não)
        verificacao = 1 
        if distanciaEmCm < 0:
            verificacao = -1

        # Inicializando o erro
        ultimoerro = 0
        percursoTotalDcc = 10  # Percurso total de correção, ajuste conforme necessário
        percursoTotal = abs(distanciaEmCm)
        
        # Loop principal de movimentação
        while movimentacaoDoRobo < abs(distanciaEmCm):
            # Atualizando os ângulos dos motores
            motorDireitaAngulo = ((abs(motorDireita.angle()) / 360) * 17.58)
            motorEsquerdaAngulo = ((abs(motorEsquerda.angle()) / 360) * 17.58)
            movimentacaoDoRobo = (motorDireitaAngulo + motorEsquerdaAngulo) / 2
            percursoFeito = movimentacaoDoRobo

            # Cálculo do erro de percurso
            percursoFeitoDcc = percursoFeito - (percursoTotal - percursoTotalDcc)

            # Cálculo do erro de direção (PID)
            erro = setpoint - hub.imu.heading()
            proporcional = erro * kp
            deltaE = erro - ultimoerro
            derivada = deltaE * kd
            correcao = proporcional + derivada

            # Cálculo da velocidade ajustada
            velocidade = abs(velocidadeInicial) - ((percursoFeitoDcc / percursoTotalDcc) * abs(velocidadeInicial))
            
            # Garantindo que a velocidade não caia abaixo de um valor mínimo
            velocidadeMinima = 46
            if abs(velocidade) < velocidadeMinima:
                velocidade = velocidadeMinima

            # Aplicando a correção nos motores
            motorDireita.run((velocidade * verificacao) - correcao)
            motorEsquerda.run((velocidade * verificacao) + correcao)

            # Exibindo o progresso
            print(f"Percurso Feito: {percursoFeito} cm")

            # Atualizando o último erro
            ultimoerro = erro

        # Parando os motores quando o percurso for concluído
        mostrarAngulo()
        motorDireita.brake()
        motorEsquerda.brake()
        wait(100)



        print('=================================')
        print(f'========= AUTO PILOTAGEM {autops} ============')
        print(f'ÂNGULO FINAL : {hub.imu.heading()}º')
        print(f'POSIÇÃO FINAL: {movimentacaoDoRobo}cm')
        print('=================================')


def curva(anguloAlvo, velocidadeInicial):
    global curvas
    curvas = curvas + 1
    if hub.imu.ready() == True:
        #velocidadeInicial = 300
        

        posicaoInicial = hub.imu.heading()
        posicaoFinal  = anguloAlvo

        #PERCURSOS
        percursoTotal = posicaoFinal - posicaoInicial
        percursoFeito = hub.imu.heading() - posicaoInicial
        if percursoTotal > 0:
            verificacao = 1
        else:
            verificacao = -1

        #PERCURSOS
        percursoTotalDcc = 60 * verificacao
        pontoDcc = posicaoFinal - percursoTotalDcc
        percursoFeitoDcc = percursoFeito - pontoDcc

        if posicaoInicial < posicaoFinal:
            while hub.imu.heading() < posicaoFinal:
                posicaoAtual = hub.imu.heading()

                percursoFeito = posicaoAtual - posicaoInicial
                
                percursoFeitoDcc = percursoFeito - pontoDcc

                
                
                if percursoFeito < pontoDcc:
                    velocidade = velocidadeInicial
                else:
                    velocidade = abs(velocidadeInicial) -  ((percursoFeitoDcc / percursoTotalDcc) * abs(velocidadeInicial))

            
                if velocidade < velocidadeMinima:
                    velocidade = velocidadeMinima

                mostrarAngulo()
                motorDireita.run(-velocidade)
                motorEsquerda.run(velocidade)
                print(hub.imu.heading())
                print(f'velocidade:{velocidade}, percursoFeito:{(percursoFeito)}, percursoTotal:{(percursoTotal)}, percursoFeitoDcc:{abs(percursoFeitoDcc)}, percursoTotalDcc:{percursoTotalDcc}')
        else:
            while hub.imu.heading() > posicaoFinal:
                posicaoAtual = hub.imu.heading()

                percursoFeito = hub.imu.heading() - posicaoInicial
                pontoDcc = posicaoFinal - percursoTotalDcc
                percursoFeitoDcc = percursoFeito - pontoDcc

                
                
                if percursoFeito > pontoDcc:
                    velocidade = velocidadeInicial
                else:
                    velocidade = abs(velocidadeInicial) -  ((percursoFeitoDcc / percursoTotalDcc) * abs(velocidadeInicial))

            
                if velocidade < velocidadeMinima:
                    velocidade = velocidadeMinima

                #mostrarAngulo()
                motorDireita.run(velocidade)
                motorEsquerda.run(-velocidade)

        mostrarAngulo()
        motorDireita.brake() 
        motorEsquerda.brake()
        wait(100)
        print('=================================')
        print(f'============ CURVA {curvas} ==============')
        print(f'ÂNGULO FINAL : {hub.imu.heading()}º')
        print('=================================')
        '''
while True:
    amperagemMaxima = 8200
    amperagemAtual = hub.battery.voltage()


    bateria = int((amperagemAtual * 100) / 8200)
    #if voltagemAtual > voltagemMaxima:
     #   bateria = 100
    wait(1000)
    print(f"Bateria: {bateria}%")
    print(hub.battery.voltage())
    #current 24


