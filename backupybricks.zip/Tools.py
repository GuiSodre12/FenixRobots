# Imports
from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch
from pybricks.parameters import Icon
from pybricks.tools import Matrix
hub = PrimeHub()

# Função que prepara ações
def prepare(func, *args, **kwargs):
    def wrapper(*inner_args, **inner_kwargs):
        # Combina os argumentos externos (args/kwargs) com os internos (inner_args/inner_kwargs)
        combined_kwargs = kwargs.copy()
        combined_kwargs.update(inner_kwargs)
        return func(*args, *inner_args, **combined_kwargs)
    return wrapper

def mostrarBateria():
    '''
        Como funciona:

        1) Ao o hub indicar que está 100% (luz verde), medir a voltagem usando
        hub.battery.voltage(). (No meu caso, Technic Large Hub, a leitura deu aproximadamente 8200kV.) 

        2)Com a bateria em 100% podemos estabelecer a seguinte relação:
             100% de Bateria(Bateria Máxima) = voltagem máxima(8200)

        3) Então multiplicamos e dividimos pela voltagem máxima:
            BateriaAtual = (VoltagemAtual * Bateria Máxima) / Voltagem máxima]

        4)Logo:
            bateria = int((voltagemAtual * 100) / voltagemMaxima)

            *int para evitar resultados "quebrados", como por ex: 49.00122032%

    Resultados devem variar de hub para hub.
    '''
    voltagemMaxima = 8200
    voltagemAtual = hub.battery.voltage()


    bateriaAtual = int((voltagemAtual * 100) / voltagemMaxima)
    if voltagemAtual > voltagemMaxima:
        bateria = 100
    #wait(1000)
    #print(bateriaAtual)
    return bateriaAtual
    #print(f"Nível de bateria do hub: {bateria}%")
    #print(hub.battery.voltage())


class Menu:
    # precisa ter uma lista de trajetórias e ele vai executar aquela que eu escolhi o índice
    def __init__(self, rotas, hub, chassi):
        self.rotas   =  rotas
        self.hub     =  hub
        self.index   =  0
        self.chassi = chassi

    #adiciona uma nova rota
    def adicionarRota(self, rota):
        self.rotas.append(rota)


    #mostra os números e passa para o lado
    def mostrar(self):
        #cria um cronometro pra implementar delay
        cronometro = StopWatch()
        cronometro.reset()
        self.hub.system.set_stop_button(Button.BLUETOOTH)
        indice = 0 + self.index
        pressed = []
        while( not (Button.CENTER in pressed) ):
            if cronometro.time() % 500 in range(10):
              
                print(f"Angulo do robô: {self.hub.imu.heading()}, Bateria do Hub: {mostrarBateria()}%")
                
            self.hub.display.char(self.rotas[indice].imagem)
            if(Button.RIGHT in pressed and indice == (len(self.rotas) - 1)):
                indice = 0
                self.index = indice
                wait(200)

            elif(Button.RIGHT in pressed and indice < (len(self.rotas) - 1)):
                indice += 1
                self.index = indice
                wait(200)


            if(Button.LEFT in pressed and indice > 0):
                indice -= 1
                self.index = indice
                wait(200)

            elif(Button.LEFT in pressed and indice == 0):
                indice = (len(self.rotas) - 1)
                self.index = indice
                wait(200)
            pressed = self.hub.buttons.pressed()
            wait(10)

        self.index = indice
        self.hub.imu.reset_heading(0)
        cond = self.rotas[indice].run()
        if cond:
            self.chassi.motorDireito.brake()
            self.chassi.motorEsquerdo.brake()
            wait(400)

        if(self.index < len(self.rotas) - 1):
            self.index += 1
       
        self.mostrar()


    
    
    

class PIDController:
    """
    Implementação de um controlador PID simples.
    
    Um controlador PID calcula um valor de controle com base em três termos:
    - Proporcional (P): que responde à diferença instantânea entre o setpoint e o valor atual.
    - Integral     (I): que responde ao histórico dessa diferença (acumulado do erro).
    - Derivativo (D): que responde à taxa de mudança do erro.
    """

    def __init__(self, Kp, Ki, Kd, setpoint=0):
        """
        Inicializa o controlador PID com os ganhos (Kp, Ki, Kd) e o setpoint desejado.

        :param Kp: Ganho proporcional.
        :param Ki: Ganho integral.
        :param Kd: Ganho derivativo.
        :param setpoint: Valor alvo que o controlador tentará alcançar.
        """
        self.Kp = Kp
        self.Ki = Ki
        self.Kd = Kd
        self.setpoint = setpoint

        # Variáveis para armazenar o estado interno do controlador
        self.previous_error = 0  # Erro na iteração anterior
        self.integral = 0  # Acúmulo do erro ao longo do tempo

    def update(self, measured_value):
        """
        Atualiza o controlador PID com o valor medido atual e calcula a saída de controle.

        :param measured_value: O valor medido do sistema (feedback).
        :return: O valor de controle calculado pelo PID.
        """
        # Calcula o erro entre o setpoint e o valor medido
        error = self.setpoint - measured_value
        
        # Termo Proporcional (P)
        P = self.Kp * error

        # Termo Integral (I)
        self.integral += error
        I = self.Ki * self.integral

        # Termo Derivativo (D)
        derivative = error - self.previous_error
        D = self.Kd * derivative

        # Calcula a saída do controlador PID
        output = P + I + D

        # Atualiza o estado interno
        self.previous_error = error

        return output

    def set_setpoint(self, setpoint):
        """
        Define um novo setpoint para o controlador.

        :param setpoint: O novo valor alvo que o controlador tentará alcançar.
        """
        self.setpoint = setpoint
        # Reseta o estado interno para evitar impactos indesejados
        self.previous_error = 0
        self.integral = 0

class LinearDecelerationRamp:
    def __init__(self, initial_speed, final_speed, total_distance, deceleration_distance):
        """
        Inicializa a rampa de desaceleração.

        :param initial_speed: Velocidade inicial do robô.
        :param final_speed: Velocidade final (deve ser zero para parada completa).
        :param total_distance: Distância total a ser percorrida durante o percurso.
        :param deceleration_distance: Distância a ser percorrida durante a desaceleração.
        """
        self.initial_speed = initial_speed
        self.final_speed = final_speed
        self.total_distance = total_distance
        self.deceleration_distance = deceleration_distance

        # Calcula o ponto de início da desaceleração
        self.start_deceleration_distance = total_distance - deceleration_distance

    def calculate_speed(self, distance_traveled):
        """
        Calcula a velocidade atual do robô com base na distância percorrida.

        :param distance_traveled: Distância já percorrida pelo robô.
        :return: A velocidade atual calculada com base na rampa de desaceleração linear.
        """
        # Se a distância percorrida for menor que o ponto de início da desaceleração, mantém a velocidade inicial
        if distance_traveled < self.start_deceleration_distance:
           # print(f"distancia percorrida: {distance_traveled}, menor que {self.start_deceleration_distance}, retornando a velocidade máxima")
            return self.initial_speed
        
        # Se a distância percorrida for maior que a distância total, retorna a velocidade final
        if distance_traveled >= self.total_distance:
           # print(f'retornando distancia final pois distanceTraveled({distance_traveled} >= total_Distance({self.total_distance}))')
            return self.final_speed

        # Calcula a fração da distância percorrida na fase de desaceleração
        distance_in_deceleration = distance_traveled - self.start_deceleration_distance
        fraction = distance_in_deceleration / self.deceleration_distance

        # Interpolação linear entre a velocidade inicial e final
        current_speed = self.initial_speed + (self.final_speed - self.initial_speed) * fraction
       # print(f"velocidade = vi + (vf - vi) * dd")
       # print(f"{current_speed} = {self.initial_speed} + ({self.final_speed} - {self.initial_speed}) * {fraction}")
        return current_speed

class Localizer:
    pass

