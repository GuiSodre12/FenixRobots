from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()
motorDireita = Motor(Port.A) #tacerto
motorEsquerda = Motor(Port.E, Direction.COUNTERCLOCKWISE) #tacerto
motorAnexoEsq = Motor(Port.F)
motorAnexoDir = Motor(Port.D)
hub.system.set_stop_button(Button.BLUETOOTH)


def autopilotagem(setpoint, distanciaEmCm, velocidadeInicial):
    #resetar valores
    hub.imu.reset_heading(0)
    motorDireita.reset_angle(0)
    motorEsquerda.reset_angle(0)
    
    
    motorDireitaAngulo =  ((motorDireita.angle() / 360) * 17.58)
    motorEsquerdaAngulo = ((motorEsquerda.angle() / 360) * 17.58)
    movimentacaoDoRobo =  (motorDireitaAngulo + motorEsquerdaAngulo) / 2

    #percurso total e feito
    kp = 31
    kd = 20.052884615384615
    


    verificacao = 1
    if distanciaEmCm < 0:
        verificacao = -1

        
    #eror
    ultimoerro = 0
    percursoTotalDcc = 10
    percursoTotal = abs(distanciaEmCm)
    while movimentacaoDoRobo < abs(distanciaEmCm):
        
        
        

        velocidadeMinima = 46
        #Movimentação do robo
        motorDireitaAngulo =  ((abs(motorDireita.angle()) / 360) * 17.58)
        motorEsquerdaAngulo = ((abs(motorEsquerda.angle()) / 360) * 17.58)
        movimentacaoDoRobo =  (motorDireitaAngulo + motorEsquerdaAngulo) / 2
        percursoFeito = movimentacaoDoRobo

        percursoFeitoDcc = percursoFeito - (percursoTotal - percursoTotalDcc)

        #PID
        erro = setpoint - hub.imu.heading()
        proporcional = erro * kp
        deltaE = erro - ultimoerro
        derivada = deltaE * kd
        correcao = (proporcional + derivada)


        velocidade = (abs(velocidadeInicial) - ((percursoFeitoDcc / percursoTotalDcc) * abs(velocidadeInicial)) )
        #print(f"percursoFeitoDcc: {percursoFeitoDcc} percursoTotalDcc: {percursoTotal}")
        if movimentacaoDoRobo < abs(distanciaEmCm) - percursoTotalDcc:
            velocidade = abs(velocidadeInicial)
            

        if abs(velocidade) < velocidadeMinima:
            velocidade = velocidadeMinima

        motorDireita.run((velocidade * verificacao) - correcao )
        motorEsquerda.run((velocidade * verificacao) + correcao )
       
        print(f" percursoFeito: {percursoFeito}")
        #ultimo erro
        ultimoerro = erro
    motorDireita.brake()
    motorEsquerda.brake()


while( not (Button.CENTER in hub.buttons.pressed()) ):
    print('a')
    
motorAnexoDir.hold()
autopilotagem(0, 18, 700)
wait(200)
motorAnexoDir.run_time(-100, 500)
motorAnexoEsq.run_time(100, 500)
autopilotagem(0, -3, 300)
autopilotagem(0, -25, 700)

while( not (Button.CENTER in hub.buttons.pressed()) ):
    print('a')


autopilotagem(0, 23, 800)
#empurra o barco
motorAnexoDir.run_time(-100, 1000)
autopilotagem(0, 72, 800)
motorAnexoEsq.run_time(900, 700)
motorAnexoDir.run_time(1000, 1000)
motorAnexoEsq.hold()
autopilotagem(0, -20, 200)
wait(100)
motorAnexoEsq.run_time(-700, 1000)
motorAnexoDir.run_time(-180, 1000)
autopilotagem(0, 18, 600)
autopilotagem(0, -20, 600)
motorAnexoDir.run_time(300, 1000)
autopilotagem(0, -12, 500)
curva(-45, 500)
autopilotagem(-45, 20, 600)
curva(5, 500)
autopilotagem(5, 300, 1000)
#curva(35, 500)
#autopilotagem(35, 30, 800)
#wait(1000)
#curva(-25)
#wait(1000)
#motorAnexoDir.run_time(600, 1000)
#autopilotagem(0, 40, 700)
#curva(45)
#autopilotagem(0, 60, 700)
#wait(1000)
#curva(-25)
#wait(1000)
#motorAnexoDir.run_time(600, 1000)
#autopilotagem(0, 40, 700)
#curva(45)
#autopilotagem(0, 60, 700)
#CARANGUEJo