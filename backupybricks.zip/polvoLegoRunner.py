from LegoRunner import *
from pybricks.hubs import PrimeHub
hub = PrimeHub()

motorAnexoDir = Motor(Port.D)
motorAnexoEsq = Motor(Port.F)


# criar a rota
movimentosCriatura = [
    prepare(chassiDoRobo.autopilotagem, -0, -50, 9000),
    prepare(chassiDoRobo.autopilotagem, 0, 50, 8000),
    #prepare(mostrarBateria())
]

movimentosColetor = [

    #prepare(chassiDoRobo.changeConstants, 400, 0000001, 100),
    prepare(chassiDoRobo.autopilotagem, 0, 11, 600),
    prepare(chassiDoRobo.curva, -14, 500),
    prepare(wait, 200),
    prepare(chassiDoRobo.autopilotagem, -14, 50, 800),
    prepare(chassiDoRobo.curva, 19
    , 500),
    prepare(wait, 200),
    prepare(chassiDoRobo.autopilotagem, 19, 10, 800),
    # prepare(chassiDoRobo.autopilotagem, 27, -10, 700),
    prepare(chassiDoRobo.curva, -81, 500),
    prepare(wait, 200),
    
    #QOOQOQOQO
    prepare(chassiDoRobo.autopilotagem, -82, 30, 800),
    prepare(chassiDoRobo.autopilotagem, -91, 31, 800),
    prepare(motorAnexoEsq.run_time, 3000, 1500),
    prepare(motorAnexoEsq.run_time, -3000, 900),
    prepare(chassiDoRobo.autopilotagem, -90, 4, 800),
    prepare(chassiDoRobo.curva, -60, 500),
    prepare(wait, 200),
    prepare(chassiDoRobo.autopilotagem, -65, 10, 800),
    prepare(chassiDoRobo.curva, -94, 600),
    prepare(wait, 200),
    prepare(chassiDoRobo.autopilotagem, -94, 46, 800),
    prepare(chassiDoRobo.curva, -158, 500),
    #prepare(wait, 200),
    prepare(chassiDoRobo.autopilotagem, -150, 70, 1000),
    

]

movimentosMergulhador = [


    #indo pro mergulhador
    prepare(chassiDoRobo.autopilotagem, 0, 16, 700),
    prepare(chassiDoRobo.curva, 40, 700),
    prepare(chassiDoRobo.autopilotagem, 40, 50, 650),
    prepare(chassiDoRobo.curva, -90, 700),
    prepare(motorAnexoDir.run_time, -1000, 800),
    prepare(chassiDoRobo.autopilotagem, -90, 13, 500),
    #pega e sai do merguldador
    prepare(motorAnexoDir.run_time, 500, 850),
    prepare(chassiDoRobo.autopilotagem, -88, -29.5, 500),
    prepare(chassiDoRobo.autopilotagem, -90, 11, 700),
    prepare(chassiDoRobo.curva, 0, 900),
    #prepare(motorAnexoDir.run_time, 500, 2500),
    prepare(chassiDoRobo.autopilotagem, -2, 14, 700),
    prepare(chassiDoRobo.autopilotagem, 0, -15, 700),
    prepare(chassiDoRobo.curva, -35, 700),
    prepare(chassiDoRobo.autopilotagem, -35, 27, 700),
    prepare(chassiDoRobo.autopilotagem, -35, -30, 900),
    prepare(chassiDoRobo.curva, 35, 600),
    prepare(chassiDoRobo.autopilotagem, 35, -80, 100000),
    #vai pra missão dos corais
    '''
    
    prepare(wait, 500),
    #abaixa pra por o mergulhador
    prepare(wait, 500),
    prepare(motorAnexoDir.run_angle, 400, -43),
    #prepare(chassiDoRobo.autopilotagem, 0, 13, 600),
    #prepare(chassiDoRobo.autopilotagem,0, -10, 600),
    #faz o coral
    prepare(chassiDoRobo.curva, -1, 300),
    prepare(chassiDoRobo.autopilotagem, 0, 9, 500),
    prepare(motorAnexoDir.run_time, -3000, 1000),
    prepare(motorAnexoDir.run_angle, 400, 25),  
    #base
    prepare(chassiDoRobo.autopilotagem, 0, -20, 700),
    prepare(chassiDoRobo.curva, 30, 800),
    prepare(chassiDoRobo.autopilotagem, 25, -100, 1000),
    prepare(wait, 1000)'''

]


movimentosColocarBarco = [

    #prepare(motorAnexoDir.hold()),
    prepare(chassiDoRobo.autopilotagem, 0, 12, 1000),

    prepare(chassiDoRobo.autopilotagem, 0, -27, 900),

]

movimentosCaranguejo = [
    
    prepare(chassiDoRobo.autopilotagem, 0, 25, 800), 
    #empurra o barco
    prepare(motorAnexoDir.run_time, -700, 1000),
    prepare(chassiDoRobo.autopilotagem, 0, 74, 900), #ANDA ATE O BARCO
    #prepare(chassiDoRobo.curva, -1, 700),
    prepare(motorAnexoEsq.run_time, 900, 700),
    prepare(motorAnexoDir.run_time, 1000, 800),
    #prepare(motorAnexoEsq.hold()),
    #prepare(chassiDoRobo.autopilotagem, 0, -17, 700), #Anda pra tras no crab trap
    #prepare(chassiDoRobo.autopilotagem, 0, -4, 90), 

    prepare(wait, 100),

    prepare(chassiDoRobo.autopilotagem,0, -19.5, 400),
    prepare(motorAnexoEsq.run, -700),
    prepare(wait, 600),
    prepare(chassiDoRobo.motorDireito.brake,),
    prepare(chassiDoRobo.motorEsquerdo.brake,),
    prepare(motorAnexoEsq.brake,),
    # prepare(chassiDoRobo.autopilotagem, 0, -3, 700),
   
    prepare(motorAnexoDir.run_time, -500, 1500),

    prepare(chassiDoRobo.autopilotagem, -10, 19, 900),
    prepare(wait, 100),
    prepare(chassiDoRobo.autopilotagem, 0, -5, 800),
    prepare(motorAnexoDir.run_time, 600, 1000),

    #Saindoooo
    prepare(chassiDoRobo.autopilotagem, 0, -11, 900),
    prepare(motorAnexoEsq.run_time, 600, -1000),
    prepare(chassiDoRobo.curva, -25, 700),
    prepare(chassiDoRobo.autopilotagem, -25, 28, 8900),
    prepare(chassiDoRobo.curva, 5, 700, False),
    prepare(chassiDoRobo.autopilotagem, 5, 70, 10000, False),

    #prepare(chassiDoRobo.autopilotagem, 0, -15, 800),
    #prepare(chassiDoRobo.autopilotagem, 20, 200, 800)
    #prepare(chassiDoRobo.curva, -40, 500),
    #prepare(chassiDoRobo.autopilotagem, -40, 10, 800),
    #prepare(chassiDoRobo.curva, 0, 500),
    #prepare(chassiDoRobo.autopilotagem, 0, 100, 10000),
    
]


movimentosBarquinho = [  
    prepare(chassiDoRobo.autopilotagem, 0, -37, 900),
    prepare(chassiDoRobo.curva, 45, 700),
    prepare(chassiDoRobo.autopilotagem, 45, -8, 500),
    prepare(motorAnexoDir.run_time, 800, 700),
    prepare(chassiDoRobo.curva, 94, 800),   
    prepare(chassiDoRobo.autopilotagem, 94, 10, 700),
    prepare(chassiDoRobo.curva, 165, 700, False, False),

    prepare(chassiDoRobo.autopilotagem, 165, -45, 900, False, False),

]

movimentosBaleia = [
    prepare(chassiDoRobo.alterarProporcional, 15),
    prepare(chassiDoRobo.alterarDerivada, 70), 
    prepare(chassiDoRobo.autopilotagem, 0, 73, 700),
    # wait(2000)
    #prepare(chassiDoRobo.curva, 38, 700),
    prepare(chassiDoRobo.curva, 38, 700),
    # wait(2000)
    prepare(chassiDoRobo.autopilotagem, 39, 18, 300),#entrando na baleia

    # wait(2000)
    prepare(chassiDoRobo.autopilotagem, 39, -8, 700),#pegando o plankton

    prepare(motorAnexoDir.run_angle, 10000, -480),
    # wait(2000)
    prepare(chassiDoRobo.autopilotagem, 39, -22, 900),
    prepare(chassiDoRobo.curva, -20, 1000, False),
    prepare(chassiDoRobo.autopilotagem, -20, -100, 10000, False),
    
]



movimentosRelogio = [

    prepare(chassiDoRobo.autopilotagem, 0, 23, 900),
    prepare(chassiDoRobo.curva,-33, 500),
    prepare(chassiDoRobo.autopilotagem, -33, 58, 1000),
    prepare(motorAnexoDir.run_time, -1000, 900),


    prepare(chassiDoRobo.autopilotagem, -40, -8, 900),
    #prepare(chassiDoRobo.curva, -43, 1000),
    #prepare(chassiDoRobo.autopilotagem, -43, -2, 1000),
    
    prepare(chassiDoRobo.curva, -65, 1000),
    prepare(chassiDoRobo.autopilotagem, -45, 14, 800),
    prepare(motorAnexoDir.run_time, 1000, 800),
    prepare(chassiDoRobo.autopilotagem, -45, -2, 800),
    prepare(chassiDoRobo.curva, -70, 900),
    prepare(motorAnexoDir.run_time, -1000, 800),
    prepare(chassiDoRobo.autopilotagem, -70, 36.5, 900),
    #prepare(chassiDoRobo.autopilotagem, -73, -2, 900),
    prepare(motorAnexoDir.run_time, 1000, 2000),
    prepare(chassiDoRobo.curva, -155, 900),
    prepare(chassiDoRobo.autopilotagem, -155, 6, 1000),
    

]

movimentosTeste = [
    # prepare(chassiDoRobo.curva, 90, 500, True),
    # prepare(wait, 1000),
    # prepare(chassiDoRobo.curva, 0, 600, True),
    # prepare(wait, 1000),
    # prepare(chassiDoRobo.curva, -90, 500, True)
    prepare(motorAnexoDir.hold),
    prepare(chassiDoRobo.autopilotagem, 0, 500000, 500, True)

]

movimentosEmergenciaCaranguejo = [
    prepare(chassiDoRobo.startPID,),
    prepare(chassiDoRobo.autopilotagem, 0, 300, 1000, False)



]



rotaCriatura = Rota('1', movimentosCriatura, 'rota criature misteriose')
rotaColetor = Rota('2', movimentosColetor, "rota coletore")
#rotaPolvo = Rota('3', movimentosPolvo, "rota polve")
rotaMergulhador = Rota('3', movimentosMergulhador, "rota mergulhadore")
rotaColocarBarco = Rota('4', movimentosColocarBarco, "rota colocar barco")
rotaCaranguejo = Rota('5', movimentosCaranguejo, "rota carangueje")
rotaBarquinho = Rota('6', movimentosBarquinho, "rota barquinho")
rotaBaleia = Rota('7', movimentosBaleia, "rota baleie")
rotaRelogio = Rota('8', movimentosRelogio, "rota relogio")
rotaTeste = Rota("T", movimentosTeste, "teste")
rotaEmergencia = Rota("9", movimentosEmergenciaCaranguejo, "Emergencia")


# adicionar as rotas
#adicionarRota(rotaTeste)
adicionarRota(rotaCriatura) #Rota 1
adicionarRota(rotaColetor)  #Rota 2
adicionarRota(rotaMergulhador) #Rota 3
adicionarRota(rotaColocarBarco)  #Rota 4
adicionarRota(rotaCaranguejo)   #Rota 5
adicionarRota(rotaBarquinho) #Rota 6
adicionarRota(rotaBaleia)   #Rota 7
adicionarRota(rotaRelogio)  #Rota 8
adicionarRota(rotaEmergencia) #Rota 9
#mostrar o menu.
menu.mostrar()
